#include <iostream>
#include <fcntl.h>
#include <zconf.h>
#include <vector>
#include <cstring>
#include <sstream>

const char *to_hex(char c) {

    int res_int = c & 0xff;

    std::stringstream s_stream;
    s_stream << std::hex << res_int;
    std::string res(s_stream.str());

    return res.c_str();
}




int main(int argc,  char *argv[]) {
    bool key = false;
    ssize_t bytes;
    std::vector<char*> files;
    for(int i=0; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            std::cout << "Arguments are the name of the files and path to them if needed. Different files are divided by space.\n";
            std::cout << "You can enter as many as you want.\n-A 	invisible symbols will be printed in hexadecimal code." << std::endl;
            exit(EXIT_SUCCESS);
        }
        else if (argc == 1){
            printf("This program was prepared be Sviatoslav Fedoriv, if you are searching more information then -h/--help.\n");
        }
        else if (strcmp(argv[i], "-A") == 0){
            key = true;
        }
        else{
            files.emplace_back(argv[i]);
        }
    }
    for(int i = 1; i < files.size(); i++){

        int fd = open(files[i], O_RDONLY);
        char buff[1000];
        ssize_t bytes;

        if (fd == -1) {

            int error_num = errno;

            if (error_num == 2) {
                std::cerr << "No such file in directory." << std::endl;
            }

            std::cerr << "Error code: " << error_num << std::endl;
            exit(error_num);
        }

        while ((bytes = read(fd, &buff, 1000)) > 0) {

            for (int i = 0; i < bytes; ++i) {
                if (key && (!(isspace(buff[i])) && !isprint(buff[i]))) {
                    
                    write(STDOUT_FILENO, to_hex(buff[i]), 1);
                } else {
                    write(STDOUT_FILENO, &buff[i], 1);
                }
            }
        }

        close(fd);
    }
    return 0;
}

